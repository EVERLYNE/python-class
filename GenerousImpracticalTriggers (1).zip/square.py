from flask import Flask
from square import square
app= Flask(__name__)
@app.route("/")
def index (name = "student"):
  return "welcome {} to Akirachix".format(name)

@app.route("/welcome/<name>")
def welcome (name="student"):
  return "welcome {}to Akirachix".format(name)

@app.route("/square/<float:length>/<int:width>")
@app.route("/square/<float:length>/<float:width>")
@app.route("/square/<int:length>/<int:width>")
@app.route("/square/<float:length>/<float:width>")

def square (length="0", width="0"):
  square = Square(length,width)

  return "sides of square is {}".format(square.area())

if __name__ =='__main__':
    app.run(host='0.0.0.0',port=8080)    