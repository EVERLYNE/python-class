from flask import Flask
from triangle import Triangle
app= Flask(__name__)
@app.route("/")
def index (name = "student"):
  return "welcome {} to Akirachix".format(name)

@app.route("/welcome/<name>")
def welcome (name="student"):
  return "welcome {}to Akirachix".format(name)

@app.route("/triangle/<float:base>/<int:height>")
@app.route("/triangle/<float:base>/<float:height>")
@app.route("/triangle/<int:base>/<int:height>")
@app.route("/triangle/<float:base>/<float:height>")

def triangle (base="0", height="0"):
  tri = Triangle (base,height)

  return "Area of triangle is {}".format(tri.area())

if __name__ =='__main__':
    app.run(host='0.0.0.0',port=8080)    