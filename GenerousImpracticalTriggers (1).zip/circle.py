from flask import Flask
from circle import Circle
app= Flask(__name__)
@app.route("/")
def index (name = "student"):
  return "welcome {} to Akirachix".format(name)

@app.route("/welcome/<name>")
def welcome (name="student"):
  return "welcome {}to Akirachix".format(name)

@app.route("/circle/<float:radius>/<int:radius>")
@app.route("/circle/<float:radius>/<float:radius>")
@app.route("/circle/<int:radius>/<int:radius>")
@app.route("/circle/<float:radius>/<float:radius>")
def circle (radius = 0, radius= 0):
  circle = Circle (radius,circle)

  return "area of circle is {}".format(circle.area())

if __name__ =='__main__':
    app.run(host='0.0.0.0',port=8080)    