marks=input("what did the student score:")
marks=int(marks)
if marks>90:
   print("A")
elif marks>70:
   print("B")
elif marks>50:
   print("C")
else:
  print ("D")