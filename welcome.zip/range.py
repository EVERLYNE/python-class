students=["Irene","Judith","Laureen"]
welcome_str="ms {} you are a good student"
for student in students:
   print(welcome_str.format(student))