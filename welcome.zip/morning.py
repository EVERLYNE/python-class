def morning ():
  print ("open eyes")
  print ("shurt alarm")
  print ("stretch")
morning()