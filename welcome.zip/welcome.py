name =input("what is your name:")
str_format="welcome {} to akirachix"
print (str_format(name))