def add_down(n):
  total=0
  for i in range(n+1):
    total=total+i
  return total
print (add_down(14))
def total_ params(args):
  total = 0
  for i in args:
    total=total+i
  
  