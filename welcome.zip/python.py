value_1=input("Enter value1")
value_2=input("Enter value2")
if value_1>value_2:
    print("value1 is greater")
else:
    print("value2 is greater")