

class triangle:
  base = 0
  height= 0
  
  def __init__(self,base,height):
    self.base = base
    self.height = height
    
  def area(self):
    return 0.5*(self.base *self.height)
    
    
  def perimeter(self):
    return (self.base + self.height + self.hypotenus)
    
small = triangle(4,5)
large = triangle(6000,7000)
print("base and height of smaller {}".format(small.base,small.height))
print("smaller area",small.area())
print("larger area",large.area())
