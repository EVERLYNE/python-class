class Student:
  def morning(self):
    returns "wakes up"
    
  def  in_class(self):
    return "learns"
  def evening(self):
    return "sleeps"
    
ivy = student()
print(ivy.morning())
print(ivy.in_class())
print(ivy.evening())