def show_params(*args):
   for i in args:
      print(i)
      
show_params("Esther","Ivy","Fay")
