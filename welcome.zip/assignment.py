students=["Irene","Maureen","Laureen","Mary","Leah","Joice","Julia","Jane","Liz","Eve",]
for i in range(10):
   print("What is the name of student {}:{}".format(i,students[i]))
  
students=["Irene","Maureen","Laureen","Mary","Leah","Joice","Julia","Jane","Liz","Eve",]
welcome_str="Welcome Ms {}"
print (welcome_str.format (students[0]))
print (welcome_str.format (students[1]))
print (welcome_str.format (students[2]))
print (welcome_str.format (students[3]))
print (welcome_str.format (students[4]))
print (welcome_str.format (students[5]))
print (welcome_str.format (students[6]))
print (welcome_str.format (students[7]))
print (welcome_str.format (students[8]))
print (welcome_str.format (students[9]))