def calculate_tax(income):
  return float(income) *0.3
income = input("what is your income;")
tax = calculate_tax(income)
  
print(tax)