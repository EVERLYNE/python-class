device=input("enter device")
if device=="feature":
   print("this is a feature")
elif device=="android":
   print("this is an android")
else:
   print("unknown device")